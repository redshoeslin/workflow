from django.db import models

class TimeAbstract(models.Model):
    add_time = models.DateTimeField(auto_now_add=True, verbose_name="添加时间")
    modify_time = models.DateTimeField(auto_now=True, verbose_name="更新时间")

    class Meta:
        abstract = True

class Project(TimeAbstract):
    name = models.CharField(default='', max_length=100, verbose_name='项目名称')
    project_type = models.CharField(default='', max_length=100, verbose_name='项目类型')
    project_owner = models.CharField(default='', max_length=100, verbose_name='开发负责人')
    project_tester = models.CharField(default='', max_length=100, verbose_name="测试负责人")
    project_leader = models.CharField(default='', max_length=100, verbose_name='project leader')
    version_num = models.IntegerField(blank=True, null=True, verbose_name='版本数量')
    repo_url = models.CharField(default='', max_length=200)
    repo_mode = models.CharField(default='', max_length=30,blank=True, null=True)
    server_ids = models.CharField(default='',max_length=10,blank=True, null=True, verbose_name='关联主机')
    last_task_status = models.CharField(max_length=20, default='',null=True, blank=True, verbose_name="状态")
    user_id = models.CharField(max_length=100, default='', blank=True, null=True, verbose_name='关联用户id')

    class Meta:
        verbose_name = '前端项目模块'
        verbose_name_plural = verbose_name

class BeProject(TimeAbstract):
    name = models.CharField(default='', max_length=100, verbose_name='项目名称')
    project_type = models.CharField(default='', max_length=100, verbose_name='项目类型')
    project_owner = models.CharField(default='', max_length=100, verbose_name='开发负责人')
    project_tester = models.CharField(default='', max_length=100, verbose_name="测试负责人")
    project_leader = models.CharField(default='', max_length=100, verbose_name='project leader')
    project_manager = models.CharField(default='', max_length=100, verbose_name='project manager')
    sit_deploy_job = models.CharField(default='', max_length=200, verbose_name='SIT deploy job')
    sit_entry_tag = models.CharField(default='', max_length=200, verbose_name='SIT entry tag')
    sit_tag = models.CharField(default='', max_length=200, verbose_name='SIT tag')
    uat_deploy_job = models.CharField(default='', max_length=200, verbose_name='UAT deploy job')
    repo_url = models.CharField(default='', max_length=200)

    class Meta:
        verbose_name = '后端项目模块'
        verbose_name_plural = verbose_name

class DeployRecord(TimeAbstract):
    name = models.CharField(default='', max_length=100, verbose_name='部署名称')
    record_id = models.CharField(default='', max_length=100, verbose_name='本次记录')
    alias = models.CharField(default='', max_length=100, verbose_name='别名')
    status = models.CharField(max_length=20,blank=True, null=True, verbose_name="状态")
    project_id = models.IntegerField(blank=True, null=True, verbose_name='关联项目')
    server_ids = models.CharField(default='', max_length=10, blank=True, null=True, verbose_name='关联主机')
    target_root = models.CharField(default='', max_length=200, verbose_name='部署路径')
    target_releases = models.CharField(default='', max_length=200, verbose_name='目标仓库')
    prev_record = models.CharField(default='', max_length=100, verbose_name='前次记录')
    is_rollback = models.BooleanField(default=False, verbose_name="可否回滚")
    class Meta:
        verbose_name = '部署记录'
        verbose_name_plural = verbose_name
