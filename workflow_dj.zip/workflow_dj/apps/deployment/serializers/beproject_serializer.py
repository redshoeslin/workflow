# @Time    : 2019/2/27 14:39
# @Author  : guilin
from rest_framework import serializers
from ..models import BeProject,DeployRecord

class BeProjectSerializer(serializers.ModelSerializer):
    '''
    项目序列化
    '''
    class Meta:
        model = BeProject
        fields = '__all__'

class BeProjectListSerializer(serializers.ModelSerializer):
    '''
    项目列表序列化
    '''
    class Meta:
        model = BeProject
        fields = ('id', 'name', 'repo_url', 'project_type', 'project_owner', 'project_tester', 'project_leader', 'project_manager', 'sit_deploy_job', 'sit_entry_tag', 'sit_tag', 'uat_deploy_job')

class DeployRecordSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeployRecord
        fields = '__all__'
