# @Time    : 2019/2/27 14:42
# @Author  : guilin
from django.urls import path,include
from deployment.views import beproject, project, deploy, applog, publish
from rest_framework import routers

router = routers.SimpleRouter()
router.register(r'projects', project.ProjectViewSet, basename="projects")
router.register(r'beprojects', beproject.BeProjectViewSet, basename="beprojects")
router.register(r'deploy/records', deploy.DeployRecordViewSet, basename="deploy_record")
urlpatterns = [
    path(r'api/', include(router.urls)),
    path(r'api/project/copy/', project.ProjectCopy.as_view(), name='project_copy'),
    path(r'api/publish/', publish.publish_pro.as_view(), name='publish')
]
