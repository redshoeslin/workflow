# @Time    : 2019/3/4 15:41
# @Author  : guilin
from rest_framework.views import APIView
from rest_framework.viewsets import ReadOnlyModelViewSet
from wf_be.code import *
from wf_be.basic import XopsResponse
from ..models import Project, DeployRecord
from cmdb.models import DeviceInfo, ConnectionInfo
from utils.shell_excu import Shell, connect_init
from rest_framework_jwt.authentication import JSONWebTokenAuthentication
import os, logging, time
from common.custom import CommonPagination, RbacPermission
from rest_framework.filters import OrderingFilter
from django_filters.rest_framework import DjangoFilterBackend
from ..serializers.project_serializer import DeployRecordSerializer
from utils.websocket_tail import Tailf
from common.custom import RedisObj
from django.conf import settings
from django.http import FileResponse

error_logger = logging.getLogger('error')
info_logger = logging.getLogger('info')


class DeployRecordViewSet(ReadOnlyModelViewSet):
    '''
    部署记录：查
    '''
    perms_map = ({'*': 'admin'}, {'*': 'deploy_all'}, {'get': 'deploy_excu'})
    queryset = DeployRecord.objects.all()
    serializer_class = DeployRecordSerializer
    pagination_class = CommonPagination
    filter_backends = (DjangoFilterBackend, OrderingFilter)
    filter_fields = ('project_id', 'status',)
    ordering_fields = ('id',)
    authentication_classes = (JSONWebTokenAuthentication,)
    permission_classes = (RbacPermission,)


