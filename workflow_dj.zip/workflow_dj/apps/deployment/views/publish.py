# @Time    : 2020/9/14 10:42
# @Author  : liguilin
from django.http import HttpResponse
from rest_framework.viewsets import ModelViewSet
from django.views.generic import View
from rest_framework.views import APIView
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework_jwt.authentication import JSONWebTokenAuthentication
from ..tasks import depoly
import os

class publish_pro(APIView):
    '''
    发布到生成环境
    '''
    def post(self, request, *args, **kwargs):
        depoly.delay()
        return HttpResponse('已发布')
