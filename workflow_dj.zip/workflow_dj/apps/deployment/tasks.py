# @Time    : 2019/2/19 14:42
# @Author  : guilin
import os
import time, logging
from utils.common import ScanSettingsLoad
from utils.shell_excu import Shell
from wf_be.celery import app
info_logger = logging.getLogger('info')

@app.task
def depoly():
    os.system("pwd && sh scripts/depoly.sh")
