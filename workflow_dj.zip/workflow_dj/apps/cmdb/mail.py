#coding=utf8
import sys
#need reload sys for email utf8
#reload(sys)
#sys.setdefaultencoding('utf8')
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage

class Email:
    def __init__(self):
        print('start send mail...')
        self.mail_html = """
        <html>
        <head></head>
        <body>
        <p>Hi receiver:<br>
        <br>
          content<br>
        <br>
        <br>
        <br>
        <br>
        <br>
        Best Regards<br>
        Integration Team
        </p>
        </body>
        </html>
        """
    def sendmail(self,email_subject,email_body,to_mail):
        fromaddr = 'ciserver@maezia.com'
        password = '4co7NGzYiB'
        toaddrs = []
        #toaddrs.append('Ping.Chen@mobilityasia.com.cn')
        toaddrs.append('guilin.li@pactera.com')
        #if " " in to_mail:
        #    mail_list=to_mail.split(' ')
        #    print(mail_list)
        #    for i in mail_list:
        #        print(i)
        #        toaddrs.append(i)
        #else:
        #    toaddrs.append(to_mail)
        #need change mail list to string
        toaddrs.append(to_mail)
        toaddrs = ','.join(toaddrs)
        receiver_name = to_mail.split('.')[0]
        email_body = self.mail_html.replace("content",email_body).replace('receiver',receiver_name)
        #message = MIMEText(mail_content,'plain',_charset='utf8')
        message = MIMEText(email_body,'html',_charset='utf8')
        message['Subject'] = email_subject
        message['From'] = fromaddr
        message['To'] = toaddrs


        try:
            #server = smtplib.SMTP('smtp.office365.com')
            server = smtplib.SMTP('smtp-n.global-mail.cn')
            server.ehlo()
            server.starttls()
            server.login(fromaddr,password)
            server.sendmail(fromaddr, toaddrs, message.as_string())
            print('email send success')
            server.quit()

        except smtplib.SMTPException as e:
            print('email send error',e)


