# @Time    : 2019/2/17 0:56
# @Author  : guilin
import os

from django.dispatch import receiver
from django.db.models.signals import post_delete

from .models import ConnectionInfo
from django.db.models import signals
from .models import DeviceFile
from .tasks import migration


@receiver(post_delete, sender=DeviceFile)
def auto_delete_file(sender, instance, **kwargs):
    if instance.file_content:
        if os.path.isfile(instance.file_content.path):
            os.remove(instance.file_content.path)

@receiver(signals.post_init, sender=ConnectionInfo)
def migrate_notify_init(instance, **kwargs):
    instance.old_approver = instance.approver

@receiver(signals.post_save, sender=ConnectionInfo)
def migrate_notify_post(instance, created, **kwargs):
    if created or instance.old_approver != instance.approver:
        migration.delay(instance.id)

