# @Time    : 2019/2/19 14:42
# @Author  : guilin
import time, logging
from utils.common import ScanSettingsLoad
from utils.shell_excu import Shell
from wf_be.celery import app
from .models import ConnectionInfo
from rbac.models import UserProfile
from .mail import Email
import re
import jenkins
info_logger = logging.getLogger('info')

@app.task
def scan_execution():
    scan_settings_load = ScanSettingsLoad()
    start_time = time.time()
    auth_type = scan_settings_load.get_conf_content('hosts', 'auth_type')
    hosts = scan_settings_load.os_scan()
    login_hosts = []
    for host in hosts:
        if host['open'] == 'open':
            login_hosts.append(host)
        elif host['os'] == 'unknown':
            DeviceScanInfo.objects.update_or_create(
                hostname=host['host'],
                defaults={
                    'os_version': host['os'],
                    'os_type': 'Other'
                }
            )
    if login_hosts:
        # 从配置文件中获取登陆认证信息和认证类型
        for host in login_hosts:
            kwargs = {
                'hostname': host['host'],
                'username': scan_settings_load.get_conf_content('hosts', 'ssh_username'),
                'port': scan_settings_load.get_conf_content('hosts', 'ssh_port'),
                'commands': scan_settings_load.get_conf_content('hosts', 'commands')
            }
            if auth_type == 'password':
                kwargs['password'] = scan_settings_load.get_conf_content('hosts', 'ssh_password')
            else:
                kwargs['password'] = scan_settings_load.get_conf_content('hosts', 'ssh_private_key')
            # 将登陆执行结果数据复制给defaults
            kwargs['auth_type'] = auth_type
            kwargs['os_type'] = 'Linux'
            # 构建连接信息
            auth_info = '{user}@{host}:{port}'.format(user=kwargs['username'], host=kwargs['hostname'],port=kwargs['port'])
            auth_key = {auth_type: kwargs['password']}
            connect = Shell(auth_info, connect_timeout=5, connect_kwargs=auth_key)
            commands = kwargs['commands']
            kwargs['error_message'] = []
            for key, value in commands.items():
                result = connect.run(value)
                if hasattr(result, 'stdout'):
                    if result.failed:
                        kwargs['status'] = 'Failed'
                        kwargs['error_message'].append(str(result.stderr) + '\n')
                    else:
                        kwargs[key] = result.stdout
                        kwargs['status'] = 'Succeed'
                        kwargs['error_message'] = ''
                    continue
                else:
                    kwargs['status'] = 'Failed'
                    kwargs['error_message'] = str(result)
                    break
            connect.close()
            defaults = kwargs
            defaults.pop('commands')
            DeviceScanInfo.objects.update_or_create(
                hostname=host['host'],
                defaults=defaults
            )
    end_time = time.time()
    msg = '扫描任务已完成, 执行时间：%(time)s秒, 共%(num)s台主机.' % {
        'time': end_time - start_time,
        'num': len(hosts)
    }
    info_logger.info(msg)
 
@app.task
def migration(uid):
    
    connect = ConnectionInfo.objects.get(id=uid)
    applyname = connect.applyname
    if applyname == 'admin':
        applymail = "guilin.li@pactera.com"
    else:
        userprofile = UserProfile.objects.get(name=applyname)
        applymail = userprofile.email
    approver = connect.approver
    approverUserProfile = UserProfile.objects.get(name=approver)
    approvermail = approverUserProfile.email
    state = connect.apply_status
    apply_url = "http://192.168.30.62:8013/cmdb/applylist"
    approver_url = "http://192.168.30.62:8013/cmdb/approvelist"
    if state == "待审批":
        apply_subject = "[已提交]-您申请的部署已提交"
        apply_content = "你申请的部署工单已提交，正在等待审批，后续有状态变更将会自动通知你。\r\n\r\n工单详情：<a href=\"" + apply_url + "\">" + apply_url + "</a>"
        Email().sendmail(apply_subject,apply_content,applymail)
        approver_subject = "[待审批]-您你有工单需要审批"
        approver_content = "你有工单需要审批，点击下方工单详情链接及时审批。\r\n\r\n工单详情：<a href=\"" + approver_url + "\">" + approver_url + "</a>"
        Email().sendmail(approver_subject,approver_content,approvermail)
    elif state == "进行中":
        apply_subject = "[执行中]-您申请的部署执行中"
        apply_content = "你申请的部署工单已通过初步审核，正在执行中，后续有状态变更将会自动通知你。\r\n\r\n工单详情：<a href=\"" + apply_url + "\">" + apply_url + "</a>"
        Email().sendmail(apply_subject,apply_content,applymail)
        approver_subject = "[待审批]-您你有工单需要审批"
        approver_content = "你有工单需要审批，点击下方工单详情链接及时审批。\r\n\r\n工单详情：<a href=\"" + approver_url + "\">" + approver_url + "</a>"
        Email().sendmail(approver_subject,approver_content,approvermail)
    elif state == "已完成":
        apply_subject = "[执行中]-您申请的部署执行中"
        apply_content = "你申请的部署工单已通过初步审核，正在执行中，后续有状态变更将会自动通知你。\r\n\r\n工单详情：<a href=\"" + apply_url + "\">" + apply_url + "</a>"
        Email().sendmail(apply_subject,apply_content,applymail)
    else:
        print("error")

@app.task
def mention(comments, author):
    mention_name = re.findall(r'@(.*?)  ', comments)
    for user in mention_name:
        user_info = UserProfile.objects.get(name=user)
        to_mail = user_info.email
        mail_subject = "[Integration Team Notification] Updates for your apply"
        mail_content = author + "  add a comment:\n  " + comments
        try:
            Email().sendmail(mail_subject,mail_content,to_mail)
        except Exception as e:
            print(e)

@app.task
def runjenkins(apply_id, name, parameters):
    jenkins_server_url = 'http://192.168.30.239:8080/'
    user_id = 'liguilin'
    api_token = '11ad0214fa18ffd8f57b55678c3c75ca1f'
    server = jenkins.Jenkins(jenkins_server_url,username=user_id,password=api_token)
    #执行Jenkins job
    try:
        queue_id = server.build_job(name,parameters)
    except Exception as e:
        print(e)
    time.sleep(15)
    build_number = server.get_queue_item(queue_id, depth=0)['executable']['number']
    build_result = server.get_build_info(name, build_number)['result']
    while (build_result is None):
        time.sleep(10)
        build_result = server.get_build_info(name, build_number)['result']
    if build_result == "SUCCESS":
        jenkins_apk_url = server.get_build_info(name, build_number)['description']
        print(jenkins_apk_url)
        url = re.search(r'(.*?)"(.*?)"(.*?)',jenkins_apk_url)
        apk_url = url.group(2)
        print(apk_url)
    else:
        apk_url = "build failed"

    ConnectionInfo.objects.filter(id=apply_id).update(apk_url=apk_url)

@app.task
def runbejenkins(apply_id, job_url, parameters, apply_status):
    jenkins_be_url = 'https://jenkins.maezia.com'
    jenkins_url = re.search(r'(.*)job(.*?)/(.*?)/', job_url)
    jenkins_server_url = jenkins_url.group(1)
    job_name=job_url.split('/')[-2]
    user_id = 'he.wang'
    api_token = '11905e1cd33ad59c9a8c00720915518233'
    server = jenkins.Jenkins(jenkins_server_url,username=user_id,password=api_token)
    jenkin_server = jenkins.Jenkins(jenkins_be_url,username=user_id,password=api_token)
    #执行Jenkins job
    try:
        queue_id = server.build_job(job_name,parameters)
    except Exception as e:
        print(e)
    time.sleep(15)
    build_number = jenkin_server.get_queue_item(queue_id, depth=0)['executable']['number']
    build_result = server.get_build_info(job_name, build_number)['result']
    while (build_result is None):
        time.sleep(10)
        build_result = server.get_build_info(job_name, build_number)['result']
    if build_result == "SUCCESS":
        #jenkins_apk_url = server.get_build_info(name, build_number)['description']
        #print(jenkins_apk_url)
        #url = re.search(r'(.*?)"(.*?)"(.*?)',jenkins_apk_url)
        if apply_status == "已完成UAT部署":
            ConnectionInfo.objects.filter(id=apply_id).update(apply_status='已完成',state='complete')
        elif apply_status == "待审批":
            ConnectionInfo.objects.filter(id=apply_id).update(apply_status='已完成SIT部署,下一步SIT_ENTRY_TAG')
        elif apply_status == "已完成SIT部署,下一步SIT_ENTRY_TAG":
            ConnectionInfo.objects.filter(id=apply_id).update(apply_status='已完成SIT_ENTRY_TAG,下一步SIT_TAG')
        elif apply_status == "已完成SIT_ENTRY_TAG,下一步SIT_TAG":
            ConnectionInfo.objects.filter(id=apply_id).update(apply_status='已完成SIT_TAG,下一步UAT部署')
        elif apply_status == "已完成SIT_TAG,下一步UAT部署":
            ConnectionInfo.objects.filter(id=apply_id).update(apply_status='已完成UAT部署')
    else:
        if apply_status == "已完成UAT部署":
            ConnectionInfo.objects.filter(id=apply_id).update(apply_status='已完成',state='complete')
        elif apply_status == "待审批":
            ConnectionInfo.objects.filter(id=apply_id).update(apply_status='SIT 部署 job failed')
        elif apply_status == "已完成SIT部署,下一步SIT_ENTRY_TAG":
            ConnectionInfo.objects.filter(id=apply_id).update(apply_status='SIT ENTRY TAG job failed')
        elif apply_status == "已完成SIT_ENTRY_TAG,下一步SIT_TAG":
            ConnectionInfo.objects.filter(id=apply_id).update(apply_status='SIT TAG job failed')
        elif apply_status == "已完成SIT_TAG,下一步UAT部署":
            ConnectionInfo.objects.filter(id=apply_id).update(apply_status='UAT 部署 job failed')

        #ConnectionInfo.objects.filter(id=apply_id).update(apply_status='job build failed')

    #ConnectionInfo.objects.filter(id=apply_id).update(apk_url=apk_url)
