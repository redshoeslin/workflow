# @Time    : 2019/2/24 20:36
# @Author  : guilin
from rest_framework import serializers
from ..models import CommentsInfo

class CommentsInfoSerializer(serializers.ModelSerializer):
    '''
    连接密码信息序列化
    '''
    uid_name = serializers.ReadOnlyField(source='uid.name')

    class Meta:
        model = CommentsInfo
        fields = '__all__'
