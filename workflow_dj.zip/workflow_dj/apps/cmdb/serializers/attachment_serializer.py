# @Time    : 2019/2/24 20:36
# @Author  : guilin
from rest_framework import serializers
from ..models import UploadFileInfo

class UploadFileInfoSerializer(serializers.ModelSerializer):
    '''
    附件信息序列化
    '''
    uid_name = serializers.ReadOnlyField(source='uid.name')

    class Meta:
        model = UploadFileInfo
        fields = '__all__'
