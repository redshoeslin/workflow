from .models import ConnectionInfo
from rbac.models import UserProfile
from .mail import Email

class Notify:
    def __init__(self):
        print('1111')
        #self.dba_list = ["dba1@ops-coffee.cn", "dba2@ops-coffee.cn"]
 
    def migration(self, uid):
    
        connect = ConnectionInfo.objects.get(id=uid)
        applyname = connect.applyname
        if applyname == 'admin':
            applymail = "guilin.li@pactera.com"
        else:
            userprofile = UserProfile.objects.get(name=applyname)
            applymail = userprofile.email
        approver = connect.approver
        approverUserProfile = UserProfile.objects.get(name=approver)
        approvermail = approverUserProfile.email
        state = connect.apply_status
        print(applyname)
        print(state)
        #print(applymail)
        print(approvermail)
        if state == "待审批":
            apply_subject = "[已提交]-您申请的部署已提交"
            apply_content = "你申请的部署工单已提交，正在等待审批，后续有状态变更将会自动通知你。\r\n\r\n工单详情："
            Email().sendmail(apply_subject,apply_content,applymail)
            approver_subject = "[待审批]-您你有工单需要审批"
            approver_content = "你有工单需要审批，点击下方工单详情链接及时审批。\r\n\r\n工单详情："
            Email().sendmail(approver_subject,approver_content,approvermail)
        elif state == "进行中":
            apply_subject = "[执行中]-您申请的部署执行中"
            apply_content = "你申请的部署工单已通过初步审核，正在执行中，后续有状态变更将会自动通知你。\r\n\r\n工单详情："
            Email().sendmail(apply_subject,apply_content,applymail)
            #approver_subject = "[待审批]-您你有工单需要审批"
            #approver_content = "你有工单需要审批，点击下方工单详情链接及时审批。\r\n\r\n工单详情："
            #Email().sendmail(approver_subject,approver_content,approvermail)

        elif state == "已完成":
            apply_subject = "[执行中]-您申请的部署执行中"
            apply_content = "你申请的部署工单已通过初步审核，正在执行中，后续有状态变更将会自动通知你。\r\n\r\n工单详情："
            Email().sendmail(apply_subject,apply_content,applymail)
        else:
            print("error")

        '''
    
        _d = "https://ops-coffee.cn/workflow/migration/%d/" %(_t.id)
        smap = {
            1: [{
                "subject": "[已提交]-[overmind]数据迁移工单",
                "content": "你的数据迁移工单已提交，正在等待DBA审批，后续有状态变更将会自动通知你。\r\n\r\n工单详情：%s" %_d,
                "reciever_list": [_u],
            }, {
                "subject": "[待审批]-[overmind]数据迁移工单",
                "content": "你有工单需要审批，点击下方工单详情链接及时审批。\r\n\r\n工单详情：%s" %_d,
                "reciever_list": self.dba_list,
            }],
            6: [{
                "subject": "[执行中]-[overmind]数据迁移工单",
                "content": "数据迁移工单已通过DBA审核，正在执行中，后续有状态变更将会自动通知你。\r\n\r\n工单详情：%s" %_d,
                "reciever_list": [_u] + self.dba_list,
            }],
            7: [{
                "subject": "[已完成]-[overmind]数据迁移工单",
                "content": "数据迁移工单已自动完成迁移，请检查最终状态，如有任何疑问随时联系DBA。\r\n\r\n工单详情：%s" %_d,
                "reciever_list": [_u] + self.dba_list,
            }]
        }
    
        _list = smap[_s]
        for i in range(0, len(_list)):
            try:
                Email(
                    subject=_list[i]['subject'], 
                    content=_list[i]['content'], 
                    reciever_list=_list[i]['reciever_list']
                )
            except Exception as e:
                print('Error:' +str(e))
        '''
