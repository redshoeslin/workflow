from datetime import datetime
from django.db import models
from django.contrib.auth import get_user_model
from simple_history.models import HistoricalRecords

User = get_user_model()

class AbstractMode(models.Model):
    pid = models.ForeignKey(
        'self', blank=True, null=True, on_delete=models.SET_NULL, related_name='child'
    )

    class Meta:
        abstract = True

class Dict(AbstractMode):
    key = models.CharField(max_length=80, verbose_name='键')
    value = models.CharField(max_length=80, verbose_name='值')
    desc = models.CharField(max_length=255, blank=True, null=True, verbose_name='备注')

    class Meta:
        verbose_name = '字典'
        verbose_name_plural = verbose_name

class TimeAbstract(models.Model):
    add_time = models.DateTimeField(auto_now_add=True, verbose_name="添加时间")
    modify_time = models.DateTimeField(auto_now=True, verbose_name="更新时间")

    class Meta:
        abstract = True

class DeviceAbstract(models.Model):
    status = models.CharField(max_length=10, blank=True, default='', verbose_name='状态')
    sys_hostname = models.CharField(max_length=100, blank=True, default='', verbose_name='主机名')
    mac_address = models.CharField(max_length=150, blank=True, default='', verbose_name='MAC地址')
    sn_number = models.CharField(max_length=150, blank=True, default='', verbose_name='SN号码')
    os_type = models.CharField(max_length=50, blank=True, default='', verbose_name='系统类型')
    os_version = models.CharField(max_length=100, blank=True, default='', verbose_name='系统版本')
    device_type = models.CharField(max_length=50, blank=True, default='', verbose_name='设备类型')
    device_model = models.CharField(max_length=150, blank=True, default='', verbose_name='设备型号')

    class Meta:
        abstract = True

class ConnectionAbstract(models.Model):
    git_repo_url = models.CharField(max_length=200, default='',verbose_name='git url')
    name = models.CharField(max_length=30, default='',verbose_name='名称')
    state = models.CharField(max_length=30, default='incomplete', verbose_name='状态')
    branch = models.CharField(max_length=50, blank=True, default='', verbose_name='git分支名')
    app_stype = models.CharField(max_length=80, blank=True, default='', verbose_name='app stype')


    class Meta:
        abstract = True

class ConnectionInfo(ConnectionAbstract, TimeAbstract):
    desc = models.CharField(max_length=150, blank=True, null=True, verbose_name='备注')
    uid = models.ForeignKey(User, null=True, blank=True, default=1, on_delete=models.SET_NULL, verbose_name='关联用户')
    apply_status = models.CharField(max_length=400, blank=True, default='待审批', verbose_name='申请状态')
    apply_type = models.CharField(max_length=80, blank=True, default='', verbose_name='工单类型')
    applyname = models.CharField(max_length=80, blank=True, default='', verbose_name='申请人')
    approver = models.CharField(max_length=80, blank=True, default='', verbose_name='当前审批人')
    develop_approver = models.CharField(max_length=80, blank=True, default='', verbose_name='开发审批人')
    test_approver = models.CharField(max_length=80, blank=True, default='', verbose_name='测试审批人')
    project_leader = models.CharField(max_length=80, blank=True, default='', verbose_name='开发leader')
    build_variant = models.CharField(max_length=80, blank=True, default='', verbose_name='build variant')
    build_version = models.CharField(max_length=80, blank=True, default='', verbose_name='build version')
    apk_url = models.CharField(max_length=400, blank=True, default='', verbose_name='apk下载地址')
    sit_deploy_job_branch = models.CharField(max_length=80, blank=True, default='', verbose_name='sit_deploy_job_branch')
    sit_entry_tag_project_version = models.CharField(max_length=80, blank=True, default='', verbose_name='sit_entry_tag_project_version')
    sit_tag_project_version = models.CharField(max_length=80, blank=True, default='', verbose_name='sit_tag_project_version')
    uat_deploy_job_project_version = models.CharField(max_length=80, blank=True, default='', verbose_name='uat_deploy_job_project_version')
    project_manager = models.CharField(max_length=80, blank=True, default='', verbose_name='project_manager')
    project_tester = models.CharField(max_length=80, blank=True, default='', verbose_name='project_tester')
    project_owner = models.CharField(max_length=80, blank=True, default='', verbose_name='project_owner')
    project_leader = models.CharField(max_length=80, blank=True, default='', verbose_name='project_leader')

    class Meta:
        verbose_name = '工单表'
        verbose_name_plural = verbose_name

class CommentsInfo(TimeAbstract):
    name = models.CharField(max_length=50, blank=True, null=True, verbose_name='姓名')
    comments = models.CharField(max_length=200, blank=True, default='', verbose_name='申请状态')
    apply_id = models.IntegerField(blank=True, verbose_name='关联工单')

    class Meta:
        verbose_name = 'comments表'
        verbose_name_plural = verbose_name

class UploadFileInfo(TimeAbstract):
    name = models.CharField(max_length=50, blank=True, null=True, verbose_name='附件名')
    apply_id = models.IntegerField(blank=True, verbose_name='关联工单')

    class Meta:
        verbose_name = '附件表'
        verbose_name_plural = verbose_name

class WorkflowInfo(models.Model):
    applyname = models.CharField(max_length=80, verbose_name='申请人')
    Git_repo_url = models.CharField(max_length=30, default='',verbose_name='git repo url')
    Branch = models.IntegerField(blank=True, default=0, verbose_name='branch')
    Build_variant = models.CharField(max_length=50, blank=True, default='', verbose_name='build variant')
    App_style = models.CharField(max_length=50, blank=True, default='', verbose_name='app style')
    message = models.CharField(max_length=200, blank=True, null=True, verbose_name='备注')


    class Meta:
        verbose_name = '工单信息'
        verbose_name_plural = verbose_name

class DeviceInfo(AbstractMode, DeviceAbstract, TimeAbstract):
    '''
    资产信息表
    '''
    auth_type = models.CharField(max_length=30, default='', verbose_name='认证类型')
    hostname = models.CharField(max_length=50, verbose_name='IP/域名')
    network_type = models.IntegerField(blank=True, null=True, verbose_name='网络类型')
    leader = models.CharField(max_length=50,blank=True, null=True, verbose_name='责任人')
    buy_date = models.DateField(default=datetime.now, verbose_name="购买日期")
    warranty_date = models.DateField(default=datetime.now, verbose_name="到保日期")
    desc = models.TextField(blank=True, default='', verbose_name='备注信息')
    changed_by = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)
    businesses = models.ManyToManyField("Business", blank=True, verbose_name="业务")
    groups = models.ManyToManyField("DeviceGroup", blank=True, verbose_name="设备组")
    labels = models.ManyToManyField("Label", blank=True, verbose_name="标签")
    history = HistoricalRecords(excluded_fields=['add_time', 'modify_time', 'pid'])

    class Meta:
        verbose_name = '设备信息'
        verbose_name_plural = verbose_name

    @property
    def _history_user(self):
        return self.changed_by

    @_history_user.setter
    def _history_user(self, value):
        self.changed_by = value

class Business(TimeAbstract):
    name = models.CharField(max_length=50, verbose_name='业务名称')
    desc = models.CharField(max_length=255, blank=True, null=True, verbose_name='备注')

    class Meta:
        verbose_name = '业务'
        verbose_name_plural = verbose_name

class DeviceGroup(TimeAbstract):
    name = models.CharField(max_length=50, verbose_name='组名')
    alias = models.CharField(default='', max_length=100, verbose_name='别名')
    desc = models.CharField(max_length=255, blank=True, null=True, verbose_name='备注')

    class Meta:
        verbose_name = '设备组'
        verbose_name_plural = verbose_name

class Label(TimeAbstract):
    name = models.CharField(max_length=50, verbose_name='标签名')
    desc = models.CharField(max_length=255, blank=True, null=True, verbose_name='备注')

    class Meta:
        verbose_name = '标签'
        verbose_name_plural = verbose_name


class DeviceFile(TimeAbstract):
    device = models.ForeignKey('DeviceInfo', blank=True, null=True, on_delete=models.SET_NULL, verbose_name='设备')
    file_content = models.FileField(upload_to="conf/asset_file/%Y/%m", null=True, blank=True, verbose_name="资产文件")
    upload_user = models.CharField(max_length=20, verbose_name="上传人")
