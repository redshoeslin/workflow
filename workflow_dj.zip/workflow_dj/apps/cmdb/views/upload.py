# @Time    : 2020/11/14 10:42
# @Author  : liguilin
from django.http import HttpResponse, FileResponse
from rest_framework.viewsets import ModelViewSet
from django.views.generic import View
from rest_framework.views import APIView
from ..serializers.business_serializer import BusinessSerializer
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework_jwt.authentication import JSONWebTokenAuthentication
import jenkins
import os
from django.conf import settings
from ..models import UploadFileInfo
import time
import re

class upload_file(APIView):
    '''
    上传文件
    '''
    def post(self, request, *args, **kwargs):
        """处理上传文件逻辑"""
        apply_id = request.data['apply_id']
        #upload_user = request.user.username
        #print(upload_user)

        fileDict = request.FILES.items()
        for (k, v) in fileDict:
            print("dic[%s]=%s" %(k,v))
            fileData = request.FILES.getlist(k)
            for file in fileData:
                fileName = file._get_name()
                #先判断有没有对应目录
                dirPath = os.path.join(settings.TEMP_FILE_PATH, apply_id)
                if os.path.isdir(dirPath):
                    print('filepath = [%s]'%dirPath)
                else:
                    os.makedirs(dirPath)
                try:
                    #先判断名称有没有同名
                    upload_data = UploadFileInfo.objects.filter(apply_id=apply_id)
                    for i in upload_data:
                        if i.name == fileName:
                            if '.' in fileName:
                                result = re.search(r'_(\d*)\.', fileName)
                                if result:
                                    new_num = int(result.group(1)) + 1
                                    old_str = "_" + result.group(1) + "."
                                    new_str = "_" + str(new_num) + "."
                                    fileName = fileName.replace(old_str, new_str)
                                else:
                                    filename_tmp = fileName.split('.')
                                    fileName = filename_tmp[0] + "_1" + "." + filename_tmp[1]
                            else:
                               fileName = fileName + "_1"
                    apply_dir = apply_id + "/" + fileName
                    filePath = os.path.join(settings.TEMP_FILE_PATH, apply_dir)

                    self.writeFile(filePath, file)
                except:
                    return HttpResponse('file write failed')
        #设置上传的文件对应工单
        UploadFileInfo.objects.create(name=fileName, apply_id=apply_id)

        return HttpResponse('已上传')

    def get(self, request, *args, **kwargs):
        """处理下载文件逻辑"""
        print('111222333')
        name=request.GET.get('name','')
        apply_id=request.GET.get('apply_id','')
        download_file = open('uploadfile/%s/%s' % (apply_id, name),'rb')
        response = FileResponse(download_file)
        response['Content-Type'] = 'application/octet-stream'
        response['Content-Disposition'] = 'attachment;filename="%s"' % name
        return response


    def writeFile(self, filePath, file):
        with open(filePath, "wb") as f:
            if file.multiple_chunks():
                for content in file.chunks():
                    f.write(content)
            else:
                data=file.read() ###.decode('utf-8')
                f.write(data)
