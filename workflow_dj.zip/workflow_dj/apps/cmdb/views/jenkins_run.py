# @Time    : 2020/9/14 10:42
# @Author  : liguilin
from django.http import HttpResponse
from rest_framework.viewsets import ModelViewSet
from django.views.generic import View
from rest_framework.views import APIView
from ..serializers.business_serializer import BusinessSerializer
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework_jwt.authentication import JSONWebTokenAuthentication
from ..models import ConnectionInfo
from deployment.models import BeProject
import jenkins
import time
from ..tasks import runjenkins, runbejenkins

class jenkins_job(APIView):
    '''
    Jenkins job管理
    '''
    def post(self, request, *args, **kwargs):
        """处理审批业务逻辑"""
        apply_status = request.data['apply_status']
        git_repo_url = request.data['git_repo_url']
        branch = request.data['branch']
        build_variant = request.data['build_variant']
        apply_id = request.data['id']
        app_style = request.data['app_stype']
        approver = request.data['approver']
        test_approver = request.data['test_approver']
        apply_type = request.data['apply_type']
        parameters={'git_repo_url':git_repo_url,'branch':branch,'build_variant':build_variant,'app_style':app_style}
        sit_deploy_job_branch = request.data['sit_deploy_job_branch']
        sit_entry_tag_project_version = request.data['sit_entry_tag_project_version']
        sit_tag_project_version = request.data['sit_tag_project_version']
        uat_deploy_job_project_version = request.data['uat_deploy_job_project_version']
        project_manager = request.data['project_manager']
        project_tester = request.data['project_tester']
        project_owner = request.data['project_owner']
        project_leader = request.data['project_leader']
        try:
            #if self.request.user.position == 'manager':
                #ConnectionInfo.objects.filter(id=apply_id).update(apply_status='进行中',approver='陈平,李桂林')
            #else:
                #if test_approver == self.request.user.name:
            if apply_type == "APK集成申请":
                name ='sveco-hu-android-build'
                if apply_status == "进行中":
                    ConnectionInfo.objects.filter(id=apply_id).update(apply_status='已完成',state='complete')
                elif apply_status == "待审批":
                    runjenkins.delay(apply_id, name, parameters)
                    ConnectionInfo.objects.filter(id=apply_id).update(apply_status='进行中',approver=test_approver)
            else:
                service_name = request.data['name']
                beproject = BeProject.objects.filter(name=service_name)
                sit_deploy_job = beproject[0].sit_deploy_job
                sit_entry_tag_job = beproject[0].sit_entry_tag
                sit_tag_job = beproject[0].sit_tag
                uat_deploy_job = beproject[0].uat_deploy_job

                if apply_status == "已完成UAT部署":
                    ConnectionInfo.objects.filter(id=apply_id).update(apply_status='已完成',state='complete')
                elif apply_status == "待审批":
                    parameters={'Branch':sit_deploy_job_branch}
                    runbejenkins.delay(apply_id, sit_deploy_job, parameters, apply_status)
                    ConnectionInfo.objects.filter(id=apply_id).update(apply_status='正在执行SIT部署 job',approver=project_tester)
                elif apply_status == "已完成SIT部署,下一步SIT_ENTRY_TAG":
                    parameters={'Project Version':sit_entry_tag_project_version}
                    runbejenkins.delay(apply_id, sit_entry_tag, parameters, apply_status)
                    ConnectionInfo.objects.filter(id=apply_id).update(apply_status='正在执行SIT_ENTRY_TAG job',approver=project_tester)
                elif apply_status == "已完成SIT_ENTRY_TAG,下一步SIT_TAG":
                    parameters={'Project Version':sit_tag_project_version}
                    runbejenkins.delay(apply_id, sit_tag, parameters, apply_status)
                    ConnectionInfo.objects.filter(id=apply_id).update(apply_status='正在执行SIT_TAG job',approver=project_owner)
                elif apply_status == "已完成SIT_TAG,下一步UAT部署":
                    parameters={'Tag Name':uat_deploy_job_project_version}
                    runbejenkins.delay(apply_id, uat_deploy_job, uat_deploy_job_project_version, parameters, apply_status)
                    ConnectionInfo.objects.filter(id=apply_id).update(apply_status='正在执行UAT部署job',approver=project_owner)

        except Exception as e:
            print("更新状态失败")

        return HttpResponse('已触发Jenkins job')

    def put(self, request, *args, **kwargs):
        """处理拒绝业务逻辑"""
        apply_id = request.data['id']
        ConnectionInfo.objects.filter(id=apply_id).update(apply_status='已拒绝',state='complete')
        return HttpResponse('已拒绝')
