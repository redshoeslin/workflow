# @Time    : 2020/9/10 
# @Author  : liguilin
import re
from rest_framework.viewsets import ModelViewSet
from ..serializers.attachment_serializer import UploadFileInfoSerializer
from common.custom import CommonPagination, RbacPermission, ObjPermission
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework_jwt.authentication import JSONWebTokenAuthentication
from ..models import CommentsInfo, UploadFileInfo
from wf_be.basic import XopsResponse
from wf_be.code import *
from django.db.models import Q

class AttachmentViewSet(ModelViewSet):
    '''
    附件信息管理：增删改查
    '''
    perms_map = ({'*': 'admin'}, {'*': 'connection_all'}, {'get': 'connection_list'}, {'post': 'connection_create'}, {'put': 'connection_edit'},
                 {'delete': 'connection_delete'})
    queryset = UploadFileInfo.objects.all()
    serializer_class = UploadFileInfoSerializer
    pagination_class = CommonPagination
    filter_backends = (SearchFilter, OrderingFilter)
    search_fields = ('apply_id',)
    ordering_fields = ('id',)
    authentication_classes = (JSONWebTokenAuthentication,)
    permission_classes = (RbacPermission,ObjPermission)

    def create(self, request, *args, **kwargs):
        comments = request.data['comments']
        request.data['name'] = request.user.username
        author = request.user.username
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return XopsResponse(serializer.data, status=CREATED, headers=headers)

    def get_queryset(self):
        perms = RbacPermission.get_permission_from_role(self.request)
        return self.queryset
