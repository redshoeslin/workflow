# @Time    : 2020/9/10 
# @Author  : liguilin
from rest_framework.viewsets import ModelViewSet
from ..serializers.connection_serializer import ConnectionInfoSerializer
from common.custom import CommonPagination, RbacPermission, ObjPermission
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework_jwt.authentication import JSONWebTokenAuthentication
from ..models import ConnectionInfo,WorkflowInfo
from rbac.models import UserProfile
from wf_be.basic import XopsResponse
from wf_be.code import *
from django.db.models import Q

class ConnectionInfoViewSet(ModelViewSet):
    '''
    表单信息管理：增删改查
    '''
    perms_map = ({'*': 'admin'}, {'*': 'connection_all'}, {'get': 'connection_list'}, {'post': 'connection_create'}, {'put': 'connection_edit'},
                 {'delete': 'connection_delete'})
    queryset = ConnectionInfo.objects.all()
    serializer_class = ConnectionInfoSerializer
    pagination_class = CommonPagination
    filter_backends = (SearchFilter, OrderingFilter)
    search_fields = ('state', 'git_repo_url', 'apply_status', 'build_version')
    ordering_fields = ('id',)
    authentication_classes = (JSONWebTokenAuthentication,)
    permission_classes = (RbacPermission,ObjPermission)

    def create(self, request, *args, **kwargs):
        # 创建密码时自动绑定uid
        request.data['uid'] = request.user.id
        request.data['applyname'] = request.user.username
        if 'admin' == request.user.username:
            pass
        else:
            #approver = UserProfile.objects.filter(id=request.user.superior_id)
            #request.data['auth_type'] = request.user.department_id
            #request.data['approver'] = approver[0].username
            pass
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return XopsResponse(serializer.data, status=CREATED, headers=headers)

    def get_queryset(self):
        '''
        当前用户只能看到自己当前审批人是自己的工单
        '''
        perms = RbacPermission.get_permission_from_role(self.request)
        if 'admin' in perms:
            return self.queryset.all()
        elif self.request.user.position == 'manager':
            return self.queryset.filter(auth_type=self.request.user.department_id)
            #return self.queryset.filter(Q(uid_id=self.request.user.id) | Q(is_public=True))
        else:
            return self.queryset.filter(Q(uid_id=self.request.user.id) | Q(approver=self.request.user.name))
