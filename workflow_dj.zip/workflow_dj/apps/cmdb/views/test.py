import jenkins
import time
import re
'''
#jenkins_server_url = 'http://192.168.30.239:8080/'
jenkins_server_url = 'http://192.168.30.239:8080/view/test-demo/job/test/view/test1/'
user_id = 'liguilin'
api_token = '11ad0214fa18ffd8f57b55678c3c75ca1f'
server = jenkins.Jenkins(jenkins_server_url,username=user_id,password=api_token)
#name ='test/view/test1/sveco-hu-android-build'
name ='sveco-hu-android-build'
git_repo_url = 'https://gitlab-rd0.maezia.com/eziash/carwash/ezia-carwash-fe-carwash'
branch = 'develop'
build_variant = 'Release'
app_style = 'AndroidAPK'
parameters={'git_repo_url': git_repo_url, 'branch': branch, 'build_variant': build_variant, 'app_style': app_style}
queue_id = server.build_job(name,parameters)
print(queue_id)

'''
#jenkins_server_url = 'https://jenkins.maezia.com/view/FAWMQB/job/fawmqb/view/SIT/job/fawmqb-sit-show/job/show-be-show-service/'
jenkins_server_url = 'https://jenkins.maezia.com/job/sveco/view/DEV/job/sveco-dev-weather/job/weather-be-service/'
url = re.search(r'(.*)job(.*?)/(.*?)/', jenkins_server_url)
#url = jenkins_server_url.split('/',1)
je_url=url.group(1)
job_name=jenkins_server_url.split('/')[-2]
print(job_name)

user_id = 'he.wang'
api_token = '11905e1cd33ad59c9a8c00720915518233'
server = jenkins.Jenkins(je_url,username=user_id,password=api_token)
#Jenkins job
#name='show-be-show-service'
parameters={'Branch': 'release_V0.23.0'}
try:
    queue_id = server.build_job(job_name, parameters)
except Exception as e:
    print(e)
time.sleep(20)
print(queue_id)
#    build_number = server.get_queue_item(queue_id, depth=0)['executable']['number']
