import time
import jenkins
import re

from celery import Celery

celery_app = Celery('a', broker='redis://localhost:6379/1')

@celery_app.task
def test_task(n):
    open('test.txt', 'a').write(n + '\n')
    print(n)

if __name__ == '__main__':
    test_task.delay('==== ttttt1 =====')
