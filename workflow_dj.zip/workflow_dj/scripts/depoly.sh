#!/bin/bash

nginx_path="/var/www/html/"
fe_path="/usr/local/workflow_web/wf_fe/"
current_date=$(date +%Y%m%d%H%M)

#backup old dist

cd ${nginx_path}
mkdir backup${current_date}
cp -r favicon.ico index.html static backup${current_date}
tar zcvf backup${current_date}.tar.gz backup${current_date}
rm -rf favicon.ico index.html static

#npm build 
cd ${fe_path}
npm run build 

cp -r dist/* ${nginx_path}

chmod 777 -R ${nginx_path}
